package repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import DAO.Paciente;

public interface PacienteIterface extends JpaRepository<Paciente,Long>{

}
