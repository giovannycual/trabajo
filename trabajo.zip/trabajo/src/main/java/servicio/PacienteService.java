package servicio;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import DAO.Paciente;
import java.util.List;
import repositorio.PacienteIterface;

@Service
public class PacienteService {

	@Autowired
	private PacienteIterface pacienteinterface;
	
	public List<Paciente> listAll(){
		return pacienteinterface.findAll();
	}
	
	public void save(Paciente paciente) {
		pacienteinterface.save(paciente);
	}
	
	public Paciente get(Long idpaciente) {
		return pacienteinterface.findById(idpaciente).get();
	}
	
	public void eliminar(Long idpaciente) {
		pacienteinterface.deleteById(idpaciente);
	}
	
}
