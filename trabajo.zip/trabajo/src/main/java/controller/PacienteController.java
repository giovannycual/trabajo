package controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import DAO.Paciente;
import java.util.List;
import servicio.PacienteService;

@Controller
public class PacienteController {
	@Autowired
	private PacienteService pacienteServicie;
	
	@RequestMapping("/")
	public String verPaginaInicia(Model modelo) {
		List<Paciente> listaPaciente=pacienteServicie.listAll();
		modelo.addAttribute("listaPaciente",listaPaciente);
		return "index";
		
	}
	@RequestMapping("/nuevo")
	public String mostrarFormularioPaciente(Model modelo) {
		Paciente paciente=new Paciente();
		modelo.addAttribute("paciente",paciente);
		return "agregar";
	}
}
