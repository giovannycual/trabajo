package DAO;

public class Tipo_docuemnt {
	private int tipodoc;
	private String descptdoc;
	private String codigo;
	private String estado;
	public Tipo_docuemnt(int tipodoc, String descptdoc, String codigo, String estado) {
		super();
		this.tipodoc = tipodoc;
		this.descptdoc = descptdoc;
		this.codigo = codigo;
		this.estado = estado;
	}
	public int getTipodoc() {
		return tipodoc;
	}
	public void setTipodoc(int tipodoc) {
		this.tipodoc = tipodoc;
	}
	public String getDescptdoc() {
		return descptdoc;
	}
	public void setDescptdoc(String descptdoc) {
		this.descptdoc = descptdoc;
	}
	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	@Override
	public String toString() {
		return "Tipo_docuemnt [tipodoc=" + tipodoc + ", descptdoc=" + descptdoc + ", codigo=" + codigo + ", estado="
				+ estado + "]";
	}
	
	
}
