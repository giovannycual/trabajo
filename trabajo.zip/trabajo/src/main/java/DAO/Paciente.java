package DAO;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Paciente {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idpaciente;
    private int tipodoc;
    private int numdoc;
    @Column(nullable=false,length = 50) 
    private String apepat;
    
    @Column(nullable=false,length = 50)
    private String apemat;
    
    @Column(nullable=false,length = 50)
    private String nombres;
    private int sexo;
    
    private String fechanac;
    private int edad;
    
    @Column(nullable=false,length = 50)
    private String naclugar;
    
    @Column(nullable=false,length = 50)
    private String direccion;

	public Paciente(Long idpaciente, int tipodoc, int numdoc, String apepat, String apemat, String nombres, int sexo,
			String fechanac, int edad, String naclugar, String direccion) {
		super();
		this.idpaciente = idpaciente;
		this.tipodoc = tipodoc;
		this.numdoc = numdoc;
		this.apepat = apepat;
		this.apemat = apemat;
		this.nombres = nombres;
		this.sexo = sexo;
		this.fechanac = fechanac;
		this.edad = edad;
		this.naclugar = naclugar;
		this.direccion = direccion;
	}

	public Paciente() {
		super();
	}

	public Long getIdpaciente() {
		return idpaciente;
	}

	public void setIdpaciente(Long idpaciente) {
		this.idpaciente = idpaciente;
	}

	public int getTipodoc() {
		return tipodoc;
	}

	public void setTipodoc(int tipodoc) {
		this.tipodoc = tipodoc;
	}

	public int getNumdoc() {
		return numdoc;
	}

	public void setNumdoc(int numdoc) {
		this.numdoc = numdoc;
	}

	public String getApepat() {
		return apepat;
	}

	public void setApepat(String apepat) {
		this.apepat = apepat;
	}

	public String getApemat() {
		return apemat;
	}

	public void setApemat(String apemat) {
		this.apemat = apemat;
	}

	public String getNombres() {
		return nombres;
	}

	public void setNombres(String nombres) {
		this.nombres = nombres;
	}

	public int getSexo() {
		return sexo;
	}

	public void setSexo(int sexo) {
		this.sexo = sexo;
	}

	public String getFechanac() {
		return fechanac;
	}

	public void setFechanac(String fechanac) {
		this.fechanac = fechanac;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public String getNaclugar() {
		return naclugar;
	}

	public void setNaclugar(String naclugar) {
		this.naclugar = naclugar;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
    
    
    
}
