package DAO;

public class Sexo {
	private int idsexo;
	private String descsexo;
	private String estado;
	public Sexo(int idsexo, String descsexo, String estado) {
		super();
		this.idsexo = idsexo;
		this.descsexo = descsexo;
		this.estado = estado;
	}
	public int getIdsexo() {
		return idsexo;
	}
	public void setIdsexo(int idsexo) {
		this.idsexo = idsexo;
	}
	public String getDescsexo() {
		return descsexo;
	}
	public void setDescsexo(String descsexo) {
		this.descsexo = descsexo;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	@Override
	public String toString() {
		return "Sexo [idsexo=" + idsexo + ", descsexo=" + descsexo + ", estado=" + estado + "]";
	}
	
	
}
